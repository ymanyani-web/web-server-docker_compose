<?php
$DB_NAME = "camagru";
$DB_DSN = "mysql:host=mysql;dbname=".$DB_NAME;
$DB_DSN_LIGHT = "mysql";
$DB_USER = "root";
$DB_PASSWORD = "tiger";
?>
