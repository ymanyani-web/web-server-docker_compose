<?php
$DB_NAME = "camagru";
$DB_DSN = "mysql:host=localhost;dbname=".$DB_NAME;
$DB_DSN_LIGHT = "localhost";
$DB_USER = "root";
$DB_PASSWORD = "tiger";
?>
