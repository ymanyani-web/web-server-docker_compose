<form action="../controller/modifier.php" method="post">
    new password: <input type="password" name="pw1"><br />
    again: <input type="password" name="pw2"><br />
    <input type="submit" name="submit" value="OK">
</form>